<?php

namespace App\Models;

use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Sluggable\HasSlug;
use Spatie\Sluggable\SlugOptions;

class Property extends Model
{
    use HasFactory, HasSlug;

    public function getSlugOptions(): SlugOptions
    {
        return SlugOptions::create()
                ->generateSlugsFrom('title')
                ->saveSlugsTo('slug');
    }
    protected $fillable = [
        'title',
        'slug',
        'description',
        'price',
        'purpose',
        'type',
        'location_id',
        'purpose_id',
        'category_id',
        'user_id',
        'bed',
        'bath',
        'area'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
    public function images()
    {
        return $this->hasMany(Image::class);
    }

    public function location()
    {
        return $this->belongsTo(Location::class);
    }
    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function purpose()
    {
        return $this->belongsTo(Purpose::class);
    }

    public function features()
    {
        return $this->hasMany(Feature::class);
    }

    public function viewRequest()
    {
        return $this->hasMany(ViewRequest::class);
    }
}
