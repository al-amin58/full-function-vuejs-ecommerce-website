<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Purpose;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class PurposeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return inertia('Purpose', [
            'purposes' => Purpose::orderBy('updated_at', 'desc')->get()
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        $data = $request->all();
        if ($request->hasFile('image')) {
            $path = '/storage/'.$request->file('image')->store('uploads', 'public');
            $data['image'] = $path;
        }
        Purpose::create($data);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $purpose = Purpose::find($id);
        $image = $purpose->image;
        if($image){
            $imagePath = str_replace('/storage', 'public', $image);
            Storage::delete($imagePath);
        }

        $purpose->delete();
    }
}
