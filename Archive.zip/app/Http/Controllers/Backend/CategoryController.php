<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Image;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Models\category;
use Inertia\Inertia;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return inertia('Category',[
            'categories' => category::latest()->get()
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {

    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
       $data = $request->all();
        if ($request->hasFile('image')) {
            $path = '/storage/'.$request->file('image')->store('uploads', 'public');
            $data['image'] = $path;
        }
        Category::create($data);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $category = Category::find($id);
        return $category;
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $category = category::find($id);
        $data = $request->all();
        if ($request->hasFile('image')) {
            $path = '/storage/'.$request->file('image')->store('uploads', 'public');
            $data['image'] = $path;
        }
        $category->update($data);
    }
    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $category = Category::find($id);
        $image = $category->image;
        if($image){
            $imagePath = str_replace('/storage', 'public', $image);
            Storage::delete($imagePath);
        }

        $category->delete();
    }
}
