<?php

namespace App\Http\Controllers\Backend;

use App\Models\Role;
use App\Models\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Request;
use Inertia\Inertia;

class DeveloperController extends Controller
{
    public function manageDeveloper()
    {
        return inertia('Developers/ManageDeveloper', [
            'developers' => Role::where('name', 'developer')->with('users')->get()->pluck('users')->flatten()
        ]);
    }
    public function developerDetail($id)
    {
        return inertia('UserDetail', [
            'developer' => User::where('id', $id)->with(['profile', 'role'])->first(),
        ]);
    }
    public function addDeveloper()
    {
        return inertia('Developers/AddDeveloper',[
            'users' => User::latest()->with('role')->get()
        ]);
    }

    public function  store()
    {

    }
    public function  deleteDeveloper($id)
    {
        $user = User::find($id);
        $user->role_id  = null;
        $user->save();
    }
}
