<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Property;
use App\Models\Purpose;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        return inertia('Dashboard', [
            'totalProperty' => Property::all()->count(),
            'rentProperty' => Purpose::where('name', 'rent')->with('properties')->get()->pluck('properties')->flatten()->count(),
            'soldProperty' => 0
        ]);
    }
}
