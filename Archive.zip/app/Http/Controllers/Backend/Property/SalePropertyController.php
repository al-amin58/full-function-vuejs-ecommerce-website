<?php

namespace App\Http\Controllers\Backend\Property;

use App\Http\Controllers\Controller;
use App\Http\Requests\PropertyStoreRequest;
use App\Models\Feature;
use App\Models\Location;
use App\Models\Property;
use App\Models\Image;
use App\Models\Category;
// use Illuminate\Http\Request;
use App\Models\Purpose;
//use Illuminate\Support\Facades\Request;
use Inertia\Inertia;
use Auth;

class SalePropertyController extends Controller
{
    public function index()
    {
        return Inertia::render('Properties/SaleProperty', [
            'locations' => Location::all(),
            'categories' => Category::orderBy('updated_at', 'desc')->get(),
            'purposes' => Purpose::where('status', 'active')->get()
        ]);
    }

    public function storeProperty(PropertyStoreRequest $req)
    {
        $data = $req->all();


        // Save Property
        $data['user_id'] = auth()->user()->id;
        $property = Property::create($data);

        // Save Multiple image
        $images = $data['images'];
        $imageData = [];
        foreach( $images as $image){
            $imageData[] = [
                'url' => '/storage/'.$image['file']->store('uploads', 'public'),
                'property_id' => $property->id
            ];
        }
        Image::insert($imageData);

        // Save Features
        $features = $data['features'];
        $featureData = [];
        foreach( $features as $feature){
            $featureData[] = [
                'property_id' => $property->id,
                'name' => $feature['name'],
                'value' => $feature['value'],
                'icon' => $feature['icon']
            ];
        }
        Feature::insert($featureData);


        return to_route('property.all');
    }
}
