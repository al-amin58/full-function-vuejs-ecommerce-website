<?php

namespace App\Http\Controllers\Backend\Property;

use App\Http\Controllers\Controller;
use App\Models\ViewRequest;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Storage;


use Inertia\Inertia;
use App\Models\Property;
use App\Models\Location;
use App\Models\Purpose;
use App\Models\Image;
use App\Models\Feature;
use App\Models\Category;


class ManagePropertyController extends Controller
{
    public function index()
    {
        return inertia('Properties/ManageProperty', [
            'properties' => Property::with('location', 'images', 'purpose', 'category', 'features')->orderBy('created_at', 'desc')->get()
        ]);
    }

    public function propertyDetail($slug){

        return inertia('Properties/PropertyDetail', [
            'property' => Property::where('slug', $slug)->with('location', 'images', 'purpose', 'category')->first()
        ]);
    }

    public function editProperty($slug)
    {
        return inertia('Properties/EditProperty', [
            'locations' => Location::all(),
            'purposes' => Purpose::where('status', 'active')->get(),
            'categories' => Category::all(),
            'property' => Property::where('slug', $slug)->with('images','location', 'purpose', 'features')->first()
        ]);
    }
    public function deletePropertyImage($id)
    {
        $image = Image::where('id', $id)->first();
        $imagePath = str_replace('/storage', 'public', $image->url);
        Storage::delete($imagePath);
        $image->delete();
    }

    // Delete Feature
    public function deleteFeature($id)
    {
        $feature = Feature::where('id', $id)->first();
        $feature->delete();
    }

    // Update Property
    public function updateProperty($slug)
    {
        $property = Property::where('slug', $slug)->first();

        $data = Request::all();
        $data['user_id'] = auth()->user()->id;

        $images = $data['newImage'];
        $imageData = [];

        foreach( $images as $image){
            $imageData[] = [
                'url' => '/storage/'.$image['file']->store('uploads', 'public'),
                'property_id' => $property->id
            ];
        }
        Image::insert($imageData);


        // Save Features
        if (isset($data['newFeatures'])){
            $features = $data['newFeatures'];
            $featureData = [];
            foreach( $features as $feature){
                $featureData[] = [
                    'property_id' => $property->id,
                    'name' => $feature['name'],
                    'value' => $feature['value'],
                    'icon' => $feature['icon']
                ];
            }
            Feature::insert($featureData);
        }


        $property->update($data);
        return to_route('property.all');
    }



    public function destroy($slug)
    {
        $property = Property::where('slug', $slug)->first();


        if ($property) {
            $images = $property->images;
            foreach ($images as $image) {
                $imagePath = str_replace('/storage', 'public', $image->url);
                Storage::delete($imagePath);
                $image->delete();
            }
            $property->delete();
        }
    }

    public function viewRequest()
    {
        return inertia('Properties/ViewRequest', [
            'requests' => ViewRequest::with('property')->get()
        ]);
    }
}
