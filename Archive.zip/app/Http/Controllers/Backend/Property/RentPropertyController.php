<?php

namespace App\Http\Controllers\Backend\Property;

use App\Http\Controllers\Controller;
use App\Models\Property;
use App\Models\Purpose;
use Illuminate\Http\Request;
use Inertia\Inertia;

class RentPropertyController extends Controller
{
    public function index()
    {
        return inertia('Properties/RentProperty', [
                'properties' => Purpose::where('name', 'rent')->with('properties.images', 'properties.location', 'properties.features', 'properties.purpose', 'properties.category')->get()->pluck('properties')->flatten()
        ]);
    }
}
