<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Location;
use App\Models\Page;
use App\Models\Property;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        $categories = Category::all();
        $locations = Location::all();
        return response()->json([
            'categories' => $categories,
            'locations' => $locations
        ]);
    }
    public function recommendedProperty()
    {
        $properties = Property::latest()->with('location', 'images', 'features', 'category')->get();
        return response()->json($properties);
    }

    public function pages()
    {
        $pages = Page::orderBy('created_at', 'desc')->get();
        return response()->json($pages);
    }
    public function showPage($slug)
    {
        $page = Page::where('slug', $slug)->first();
        return response()->json($page);
    }
}
