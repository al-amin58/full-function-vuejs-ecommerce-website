<?php

namespace App\Http\Controllers\Api\V1\Property;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Property;
use App\Models\Purpose;
use Illuminate\Http\Request;

class PropertySearchController extends Controller
{
    public function searchProperty(Request $request)
    {
        $purpose = $request->input('purpose');
        $categoryId = $request->input('categoryId');

        if ($purpose != null) {
            $properties = Purpose::where('name', $purpose)
                ->with('properties.images', 'properties.location', 'properties.features', 'properties.purpose', 'properties.category')
                ->get()
                ->pluck('properties')
                ->flatten();
        }
        if ($categoryId != null) {
            $properties = Category::where('id', $categoryId)
                ->with('properties.images', 'properties.location', 'properties.features', 'properties.purpose', 'properties.category')
                ->get()
                ->pluck('properties')
                ->flatten();
        }
        return response()->json($properties);
    }
    public function propertyDetail($slug)
    {
        $property = Property::where('slug', $slug)->with('images', 'location', 'category', 'features', 'purpose')->first();
        return response()->json($property);
    }
}
