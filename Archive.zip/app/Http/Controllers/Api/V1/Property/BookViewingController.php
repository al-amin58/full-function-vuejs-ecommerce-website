<?php

namespace App\Http\Controllers\Api\V1\Property;

use App\Http\Controllers\Controller;
use App\Models\Property;
use App\Models\ViewRequest;
use Illuminate\Http\Request;

class BookViewingController extends Controller
{
    public function index($slug)
    {
        $property = Property::where('slug', $slug)->with('images', 'location', 'category', 'features', 'purpose')->first();
        return response()->json($property);
    }

    public function BookViewing(Request $request)
    {
       $data = $request->validate([
           'date' => 'required',
           'name' => 'required',
           'phone' => 'required',
           'email' => 'email|nullable',
           'property_id' => 'numeric'
       ]);
      ViewRequest::create($data);
    }
}
