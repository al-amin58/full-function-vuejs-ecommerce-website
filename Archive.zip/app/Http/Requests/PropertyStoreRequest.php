<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PropertyStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'title' => 'required',
            'description' => 'required',
            'price' => 'required',
            'category_id' => 'required',
            'purpose_id' => 'required',
            'location_id' => 'required',
        ];

    }

    public function message(): array
    {
        return [
            'title.required' => 'The title field is required',
            'description.required' => 'The description filed is required',
            'price.required' => 'Price field is required',
            'category_id.required' => 'property must need a category',
            'purpose_id.required' => 'property must need a purpose',
            'location_id' => 'Property location is required',
        ];
    }
    protected  $stopOnFirstFailure = true;
}
