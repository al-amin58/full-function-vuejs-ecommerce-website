<script setup>
import { Head, Link } from '@inertiajs/vue3';

defineProps({
    canLogin: {
        type: Boolean,
    },
    canRegister: {
        type: Boolean,
    },
    laravelVersion: {
        type: String,
        required: true,
    },
    phpVersion: {
        type: String,
        required: true,
    },
});
</script>

<template>
    <Head title="Welcome" />

    <!-- <div
        class="relative sm:flex sm:justify-center sm:items-center min-h-screen bg-dots-darker bg-center bg-gray-100 dark:bg-dots-lighter dark:bg-gray-900 selection:bg-red-500 selection:text-white"
    >
        <div v-if="canLogin" class="sm:fixed sm:top-0 sm:right-0 p-6 text-end">
            <Link
                v-if="$page.props.auth.user"
                :href="route('dashboard')"
                class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500"
                >Dashboard</Link
            >

            <template v-else>
                <Link
                    :href="route('login')"
                    class=""
                    >Log in</Link
                >

                <Link
                    v-if="canRegister"
                    :href="route('register')"
                    class=""
                    >Register</Link
                >
            </template>
        </div>
    </div> -->

    <GuestLayout>
        <div class="min-vh-100 d-flex align-items-center justify-content-center">
            <h1 class="w-50 mx-auto text-center fw-bold" >
                Welcome To  <span class="secondary-color" style="text-decoration: underline;">ISO</span> <span class="primary-color" style="text-decoration: underline;">Holdings</span> Please 
                <Link href="/login" class="secondary-color fw-bold" style="text-decoration: underline;">Log In</Link> To Get Access to the Dashboard.
            </h1>
        </div>
    </GuestLayout>
</template>
