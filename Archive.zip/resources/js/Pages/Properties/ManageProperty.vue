<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Link } from '@inertiajs/vue3'
import PropertyDetail from '@/Components/PropertyDetail.vue'
import Pagination from '@/Components/Pagination.vue'
import { Head } from '@inertiajs/vue3'

defineProps({
    properties:Array
})

</script>


<template>
    <Head title="Properties" />
    <AuthenticatedLayout>
        <div class="bg-white shadow p-5 rounded mb-4 d-flex align-items-center justify-content-between">
            <h2>All Properties </h2>
            <div>
                <Link href="/property/sale" class="iso-icon-box button-primary">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-building-add" viewBox="0 0 16 16">
                    <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7m.5-5v1h1a.5.5 0 0 1 0 1h-1v1a.5.5 0 0 1-1 0v-1h-1a.5.5 0 0 1 0-1h1v-1a.5.5 0 0 1 1 0"/>
                    <path d="M2 1a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6.5a.5.5 0 0 1-1 0V1H3v14h3v-2.5a.5.5 0 0 1 .5-.5H8v4H3a1 1 0 0 1-1-1z"/>
                    <path d="M4.5 2a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5zm3 0a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5zm3 0a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5zm-6 3a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5zm3 0a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5zm3 0a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5zm-6 3a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5zm3 0a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5z"/>
                    </svg>Add Property
                </Link>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-lg-10">
                <div class="d-flex flex-column gap-3">
                    <div v-for="property in properties" class="property shadow" :key="property.id">
                        <div class="property-images">
                            <img :src="property.images[0]?.url" :alt="property.title">
                        </div>
                        <div class="property-detail">
                            <h3 class="property-detail-title mb-1">
                                <Link :href="`/properties/${property.slug}`" class="iso-hover-primary">{{ property.title }}</Link>
                            </h3>
                            <div class="location">
                                <i class="bi bi-geo-alt-fill"></i>
                                <p>{{ property.location.name }}</p>
                            </div>
                            <h3 class="price my-2">{{ property.price}} BDT</h3>
                            <div class="d-flex align-items-center gap-2 type my-2">
                                <span class="iso-primary-bg">{{ property.category?.name }}</span>
                                <span class="iso-secondary-bg">{{ property.purpose?.name }}</span>
                            </div>
                            <div class="d-flex align-items-center justify-content-between mt-3">
                                <ul class="d-flex align-items-center flex-wrap gap-3 property-items">
                                    <li   v-for="feature in property.features.slice(0,3)" class=" fw-medium d-flex align-items-center gap-2">
                                        <div v-html="feature.icon"></div>
                                        {{ feature.name }}
                                        <span>{{ feature.value }}</span>
                                    </li>
                                    <li v-if="property.features.length > 3">
                                        <Link to="#" class="primary-color"> +{{ property.features.length - 3 }} more..</Link>
                                    </li>
                                </ul>
                                <ul class="d-flex align-items-center gap-2 actions">
                                    <!--                        <li>-->
                                    <!--                            <Link href="" method="get" class="detail" data-bs-toggle="modal" data-bs-target="#productModal">-->
                                    <!--                                <i class="bi bi-eye"></i>-->
                                    <!--                            </Link>-->
                                    <!--                        </li>-->
                                    <li>
                                        <Link :href="`/edit/${property.slug}`" class="edit">
                                            <i class="bi bi-pencil-square"></i> Edit
                                        </Link>
                                    </li>
                                    <li>
                                        <Link :href="`/delete/${property.slug}`"  class="delete">
                                            <i class="bi bi-trash"></i> Delete
                                        </Link>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
<!--        Pagination -->
        <Pagination
         :links="properties"
        />

    </AuthenticatedLayout>
</template>
