<script setup>

import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout.vue";
import { Link } from '@inertiajs/vue3'

const props = defineProps({
    requests:Array
})
const FRONTEND_URL = 'https://isoholdings.com/'
</script>

<template>
    <AuthenticatedLayout>
        <section>
            <div class="container">
                <div class="row flex-column">
                    <div class="col-lg-9">

                        <div class="rounded shadow p-4 bg-white mb-4" v-for="request in requests">
                            <ul class="d-flex flex-column gap-2">
                                <li class="d-flex fw-semibold text-dark">
                                    <p class="w-20">Date</p>
                                    <p class="text-dark">{{ request.date }}</p>
                                </li>
                                <li class="d-flex fw-semibold text-dark">
                                    <p class="w-20">Name</p>
                                    <p class="text-dark">{{ request.name }}</p>
                                </li>
                                <li class="d-flex fw-semibold text-dark">
                                    <p class="w-20">Phone</p>
                                    <a :href="`tel:${request.phone}`" class="text-dark fw-semibold">{{ request.phone }}</a>
                                </li>
                                <li class="d-flex fw-semibold text-dark">
                                    <p class="w-20">Email</p>
                                    <p class="text-dark" v-if="request.email" >{{ request.email }}</p>
                                    <p class="text-secondary" v-else>No Email Provided</p>
                                </li>
                                <li class="d-flex fw-semibold text-dark ">
                                    <p class="w-20">Property</p>
                                    <a :href="`${FRONTEND_URL}/property-detail/${request.property.slug}`" target="_blank" class=" text-dark fw-semibold">{{ request.property.title }}</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </AuthenticatedLayout>
</template>

<style scoped>

</style>
