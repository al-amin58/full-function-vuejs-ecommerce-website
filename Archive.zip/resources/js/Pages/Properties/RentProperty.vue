<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import {Link} from "@inertiajs/vue3";

const props = defineProps({
    properties: Array
})
</script>


<template>
    <AuthenticatedLayout>
        <div class="bg-white shadow p-5 rounded">
            <h2>Rent Property</h2>
        </div>

        <div class="row mt-5">
            <div class="col-lg-10">
                <div class="d-flex flex-column gap-3">
                    <div v-for="property in properties" class="property shadow" :key="property.id">
                        <div class="property-images">
                            <img :src="property.images[0]?.url" :alt="property.title">
                        </div>
                        <div class="property-detail">
                            <h3 class="property-detail-title mb-1">
                                <Link :href="`/properties/${property.slug}`" class="iso-hover-primary">{{ property.title }}</Link>
                            </h3>
                            <div class="location">
                                <i class="bi bi-geo-alt-fill"></i>
                                <p>{{ property.location.name }}</p>
                            </div>
                            <h3 class="price my-2">{{ property.price}} BDT</h3>
                            <div class="d-flex align-items-center gap-2 type my-2">
                                <span class="iso-primary-bg">{{ property.category?.name }}</span>
                                <span class="iso-secondary-bg">{{ property.purpose?.name }}</span>
                            </div>
                            <div class="d-flex align-items-center justify-content-between mt-3">
                                <ul class="d-flex align-items-center flex-wrap gap-3 property-items">
                                    <li   v-for="feature in property.features.slice(0, 3)" class=" fw-medium d-flex align-items-center gap-2">
                                        <div v-html="feature.icon"></div>
                                        {{ feature.name }}
                                        <span>{{ feature.value }}</span>
                                    </li>
                                    <li v-if="property.features.length > 3">
                                        <Link to="#" class="primary-color"> +{{ property.features.length - 3 }} more..</Link>
                                    </li>
                                </ul>
                                <ul class="d-flex align-items-center gap-2 actions">
                                    <!--                        <li>-->
                                    <!--                            <Link href="" method="get" class="detail" data-bs-toggle="modal" data-bs-target="#productModal">-->
                                    <!--                                <i class="bi bi-eye"></i>-->
                                    <!--                            </Link>-->
                                    <!--                        </li>-->
                                    <li>
                                        <Link :href="`/edit/${property.slug}`" class="edit">
                                            <i class="bi bi-pencil-square"></i> Edit
                                        </Link>
                                    </li>
                                    <li>
                                        <Link :href="`/delete/${property.slug}`"  class="delete">
                                            <i class="bi bi-trash"></i> Delete
                                        </Link>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </AuthenticatedLayout>
</template>
