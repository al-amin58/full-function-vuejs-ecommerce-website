<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Link } from '@inertiajs/vue3'
</script>

<template>
    <AuthenticatedLayout>
        <div class="payment-method">
            <div class=" p-3 shadow rounded d-flex align-items-center justify-content-between bg-white">
                <h3>Payments Methods</h3>
                <button class="button-primary d-flex align-items-center gap-2">
                    <i class="bi bi-patch-plus-fill"></i>Add New Payment Method
                </button>
            </div>
            <table class="table table-hover mt-4 bg-white rounded shadow">
                <thead>
                    <tr style="background: #1C2A48;">
                        <th class="text-white">ID</th>
                        <th class="text-white">Method Logo</th>
                        <th class="text-white">Method Name</th>
                        <th class="text-white">Method Number</th>
                        <th class="text-white">Instruction</th>
                        <th class="text-white">Status</th>
                        <th class="text-white">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr >
                        <td>1</td>
                        <td>
                            <img src="@/assets/images/paypel.png" style="width: 100px;height: auto;" alt="Method Logo">
                        </td>
                        <td>Paypel</td>
                        <td>01522222222</td>
                        <td style="max-width: 300px;font-size:14px;">first payment your balance in this number , after type this number and your transaction id. CRC null</td>
                        <td>
                            <span class="iso-secondary-bg text-white rounded p-1">In-Active</span>
                        </td>
                        <td>
                            <div class="d-flex gap-2">
                                <Link href="" class="edit">
                                    <i class="bi bi-pencil-square"></i>
                                </Link>
                                <Link href=""  class="delete">
                                    <i class="bi bi-trash"></i>
                                </Link>
                            </div>
                        </td>
                    </tr>
                    <tr >
                        <td>2</td>
                        <td>
                            <img src="@/assets/images/bkash.png" style="width: 100px;height: auto;" alt="Method Logo">
                        </td>
                        <td>Bkash</td>
                        <td>01522222222</td>
                        <td style="max-width: 300px;font-size:14px;">first payment your balance in this number , after type this number and your transaction id. CRC null</td>
                        <td>
                            <span class="iso-secondary-bg text-white rounded p-1">In-Active</span>
                        </td>
                        <td>
                            <div class="d-flex gap-2">
                                <Link href="" class="edit">
                                    <i class="bi bi-pencil-square"></i>
                                </Link>
                                <Link href=""  class="delete">
                                    <i class="bi bi-trash"></i>
                                </Link>
                            </div>
                        </td>
                    </tr>
                    <tr >
                        <td>3</td>
                        <td>
                            <img src="@/assets/images/Payoneer.png" style="width: 100px;height: auto;" alt="Method Logo">
                        </td>
                        <td>Payoneer</td>
                        <td>01522222222</td>
                        <td style="max-width: 300px;font-size:14px;">first payment your balance in this number , after type this number and your transaction id. CRC null</td>
                        <td>
                            <span class="iso-secondary-bg text-white rounded p-1">In-Active</span>
                        </td>
                        <td>
                            <div class="d-flex gap-2">
                                <Link href="" class="edit">
                                    <i class="bi bi-pencil-square"></i>
                                </Link>
                                <Link href=""  class="delete">
                                    <i class="bi bi-trash"></i>
                                </Link>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </AuthenticatedLayout>
</template>