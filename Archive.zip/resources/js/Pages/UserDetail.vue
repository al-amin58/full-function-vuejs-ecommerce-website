<script setup>

import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout.vue";
import { Link } from '@inertiajs/vue3'

const props = defineProps({
    developer:Object,
})
</script>

<template>
    <AuthenticatedLayout>
        <div class="user-card-detail">
            <div class="row">
                <div class="col-lg-4">
                    <div class="user-card-detail__left shadow bg-white">
                        <div class="user-card-detail__left-img">
                            <img src="https://img.freepik.com/free-photo/medium-shot-man-posing-studio_23-2150275677.jpg?size=626&ext=jpg&uid=R102446229&ga=GA1.1.1632597065.1693842988&semt=sph" alt="User Image">
                        </div>
                        <div>
                            <h3>{{ developer.name}}</h3>
                            <p>{{developer.role.name }}</p>
                        </div>
                        <div class="d-flex align-items-center justify-content-center gap-3 mt-3">
                            <Link href="" class="edit">
                                <i class="bi bi-pencil-square"></i>Edit
                            </Link>
                            <Link href="" class="delete">
                                <i class="bi bi-trash"></i> Delete
                            </Link>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="user-card-detail__right shadow bg-white">
                        <ul v-if="developer.profile">
                            <li>
                                <strong>Email </strong>
                                <p>{{ developer.profile?.email}}</p>
                            </li>
                            <li>
                                <strong>Secondary Email </strong>
                                <p>{{ developer.profile?.secondary_email}}</p>
                            </li>
                            <li>
                                <strong>Phone </strong>
                                <p>{{ developer.profile?.phone}}</p>
                            </li>
                            <li>
                                <strong>Age </strong>
                                <p>{{ developer.profile?.age}}</p>
                            </li>
                            <li>
                                <strong>Country </strong>
                                <p>{{ developer.profile?.country }}</p>
                            </li>
                            <li>
                                <strong>City </strong>
                                <p>{{ developer.profile?.city}}</p>
                            </li>
                            <li>
                                <strong>Address </strong>
                                <p>{{ developer.profile?.address}}</p>
                            </li>
                        </ul>
                        <p v-else>This Developer doesn't have more information!</p>
                    </div>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
</template>

<style scoped>

</style>
