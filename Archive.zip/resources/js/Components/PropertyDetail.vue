<script setup>
</script>

<template>
    <div class="property-detail">
        <div class="modal fade"  id="productModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <i class="bi bi-x-lg"></i>
                    </button>
                    <div class="row property-detail-top">
                        <div class="col-9">
                            <div class="property-detail-top-main">
                                <img src="@/assets/images/property.png" alt="">
                            </div>
                        </div>
                        <div class="col-3">
                            <ul class="property-detail-top-sub d-flex flex-column gap-3">
                                <li>
                                    <img src="@/assets/images/property-3.png" alt="Property Two">
                                </li>
                                <li>
                                    <img src="@/assets/images/property-2.png" alt="Property Two">
                                </li>
                                <li>
                                    <img src="@/assets/images/property-3.png" alt="Property Two">
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="property-detail-body">
                        <div class="d-flex align-items-center justify-content-between my-5">
                            <h2>BDT 17000</h2>
                        </div>
                        
                        <h3 class="mb-4">Mohammadia Housing Society, Mohammadpur, Dhaka</h3>

                        <ul class="d-flex align-items-center gap-5">
                            <li  class="text-dark fw-medium d-flex align-items-center gap-2">
                                <svg xmlns="http://www.w3.org/2000/svg" height="16" width="20" viewBox="0 0 640 512"><path d="M32 32c17.7 0 32 14.3 32 32V320H288V160c0-17.7 14.3-32 32-32H544c53 0 96 43 96 96V448c0 17.7-14.3 32-32 32s-32-14.3-32-32V416H352 320 64v32c0 17.7-14.3 32-32 32s-32-14.3-32-32V64C0 46.3 14.3 32 32 32zm144 96a80 80 0 1 1 0 160 80 80 0 1 1 0-160z"/></svg>
                                1 Bed
                                
                            </li>
                            <li  class="text-dark fw-medium d-flex align-items-center gap-2">
                                <svg xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 512 512"><path d="M96 77.3c0-7.3 5.9-13.3 13.3-13.3c3.5 0 6.9 1.4 9.4 3.9l14.9 14.9C130 91.8 128 101.7 128 112c0 19.9 7.2 38 19.2 52c-5.3 9.2-4 21.1 3.8 29c9.4 9.4 24.6 9.4 33.9 0L289 89c9.4-9.4 9.4-24.6 0-33.9c-7.9-7.9-19.8-9.1-29-3.8C246 39.2 227.9 32 208 32c-10.3 0-20.2 2-29.2 5.5L163.9 22.6C149.4 8.1 129.7 0 109.3 0C66.6 0 32 34.6 32 77.3V256c-17.7 0-32 14.3-32 32s14.3 32 32 32H480c17.7 0 32-14.3 32-32s-14.3-32-32-32H96V77.3zM32 352v16c0 28.4 12.4 54 32 71.6V480c0 17.7 14.3 32 32 32s32-14.3 32-32V464H384v16c0 17.7 14.3 32 32 32s32-14.3 32-32V439.6c19.6-17.6 32-43.1 32-71.6V352H32z"/></svg>
                                1 Bath
                            </li>
                            <li class="text-dark fw-medium d-flex align-items-center gap-2">
                                <svg xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 512 512"><path d="M448 96V224H288V96H448zm0 192V416H288V288H448zM224 224H64V96H224V224zM64 288H224V416H64V288zM64 32C28.7 32 0 60.7 0 96V416c0 35.3 28.7 64 64 64H448c35.3 0 64-28.7 64-64V96c0-35.3-28.7-64-64-64H64z"/></svg>
                                600 sqft
                            </li>
                        </ul>

                        <h4 class="my-3">This 600 Sq. ft -1 Bedroom Convenient Flat Is For Rent In Mohammadia Housing Society</h4>
                        <p>Great news for the apartment searchers! If you are looking for a new beautiful home in Mohammadpur, look no further! We have great news, a lovely and affordable 600  Square Feet home located in Mohammadpur is all ready for you to shift. The flat comprises a spacious area in this specific area featuring enough space for relaxed living. There are 1 bed and 1 bath and nice balconies in the apartment. The area has improved transportation facilities to maintain smooth overall connectivity to other parts of the city. </p>


                        <h3 class="mt-5 mb-2">Property Information</h3>
                        <ul class="property-info mb-5">
                            <li class="border-bottom py-2">
                                <span>Type</span>
                                <span class="text-capitalize fw-semibold">Apartment</span>
                            </li>
                            <li class="border-bottom py-2">
                                <span>Reference no.</span>
                                <span class="text-capitalize fw-semibold">ISO - ID4434512</span>
                            </li>
                            <li class="border-bottom py-2">
                                <span>Purpose</span>
                                <span class="text-capitalize fw-semibold">For Rent</span>
                            </li>
                            <li class="border-bottom py-2">
                                <span>Last Updated</span>
                                <span class="text-capitalize fw-semibold">11 January 2024</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>