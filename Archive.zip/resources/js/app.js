import './bootstrap.js'
import '../css/app.css';
import './assets/css/main.css';
// import './assets/js/bootstrap-select.min.js';
import './assets/js/popper.min.js';
import './assets/js/bootstrap.bundle.min.js';

import 'summernote/dist/summernote-bs4.css'
import 'summernote/dist/summernote-bs4.min.js'

import 'vue-select/dist/vue-select.css';


import { createApp, h } from 'vue';
import { createInertiaApp } from '@inertiajs/vue3';
import { resolvePageComponent } from 'laravel-vite-plugin/inertia-helpers';
import { ZiggyVue } from '../../vendor/tightenco/ziggy/dist/vue.m';
import VueApexCharts from "vue3-apexcharts";
import vSelect from 'vue-select'
import Swal from "sweetalert2";

import { createVbPlugin } from 'vue3-plugin-bootstrap5'
import { Alert, Button, Carousel, Collapse, Dropdown, Modal, Offcanvas, Popover, ScrollSpy, Tab, Toast, Tooltip } from 'bootstrap'
let vbPlugin = createVbPlugin({ Alert, Button, Carousel, Collapse, Dropdown, Modal, Offcanvas, Popover, ScrollSpy, Tab, Toast, Tooltip})



import { createToaster } from "@meforma/vue-toaster"
window.$toast = createToaster({
    position: 'bottom-right'
});


// window.Swal = Swal
// const Toast = Swal.mixin({
//     toast: true,
//     position:'top-end',
//     showConfirmButton:false,
//     timer:5000,
//     icon:true,
// })


const appName = import.meta.env.VITE_APP_NAME || 'Laravel';
window.FRONTEND_URL = import.meta.env.FRONTEND_URL;

createInertiaApp({
    title: (title) => `${title} - ${appName}`,
    resolve: (name) => resolvePageComponent(`./Pages/${name}.vue`, import.meta.glob('./Pages/**/*.vue')),
    setup({ el, App, props, plugin }) {
        return createApp({ render: () => h(App, props) })
            .use(plugin)
            .use(ZiggyVue)
            .use(VueApexCharts)
            .use(vbPlugin)
            .use(FRONTEND_URL)
            .component("v-select", vSelect)
            .mount(el);
    },
    progress: {
        color: '#4B5563',
    },
});
