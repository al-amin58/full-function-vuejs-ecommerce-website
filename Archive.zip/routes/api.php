<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Api\V1\Auth\LoginController;
use App\Http\Controllers\Api\V1\Auth\RegisterController;
use App\Http\Controllers\Api\V1\Auth\LogoutController;
use App\Http\Controllers\Api\V1\Property\PropertySearchController;
use App\Http\Controllers\Api\V1\Property\BookViewingController;
use App\Http\Controllers\Api\V1\HomeController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});


// Auth
Route::post('/register', [RegisterController::class, 'register']);
Route::post('/login', [LoginController::class, 'login']);

//Property
Route::get('/category-location', [HomeController::class, 'index']);
Route::get('/property/search', [PropertySearchController::class, 'searchProperty']);

Route::get('/recommended-property', [HomeController::class, 'recommendedProperty']);
Route::get('/property-detail/{slug}', [PropertySearchController::class, 'propertyDetail']);


Route::get('/book-viewing/{slug}', [BookViewingController::class, 'index']);
Route::post('/book-viewing', [BookViewingController::class, 'BookViewing']);

// Page
Route::get('/pages', [HomeController::class, 'pages']);
Route::get('/page/{slug}', [HomeController::class, 'showPage'])->name('front.page');

