<?php

use App\Http\Controllers\Backend\Property\BuyPropertyController;
use App\Http\Controllers\Backend\Property\ManagePropertyController;
use App\Http\Controllers\Backend\Property\RentPropertyController;
use App\Http\Controllers\Backend\Property\SalePropertyController;

use App\Http\Controllers\Backend\PurposeController;
use App\Http\Controllers\Backend\PageController;
use App\Http\Middleware\SuperAdmin;

use App\Http\Controllers\Backend\PaymentMethodController;
use App\Http\Controllers\Backend\CategoryController;
use App\Http\Controllers\Backend\SettingsController;
use App\Http\Controllers\Backend\DeveloperController;
use App\Http\Controllers\Backend\DashboardController;
use App\Http\Controllers\ProfileController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return Inertia::render('Welcome', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
    ]);
});

route::get('/dashboard', [DashboardController::class, 'index'])->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';


Route::middleware('auth')->group(function() {

//! Property Routes

//  Manage
    Route::get('/properties', [ManagePropertyController::class, 'index'])->name('property.all');
    Route::get('/properties/{slug}', [ManagePropertyController::class, 'propertyDetail']);
    Route::get('/edit/{slug}', [ManagePropertyController::class, 'editProperty']);
    Route::post('/update/{slug}', [ManagePropertyController::class, 'updateProperty']);
    Route::get('/delete/{slug}', [ManagePropertyController::class, 'destroy']);

// Delete Feature
    Route::get('/delete-feature/{id}', [ManagePropertyController::class, 'deleteFeature']);

// Sale
    Route::get('/property/sale', [SalePropertyController::class, 'index'])->name('property.add');
    Route::post('/store-property', [SalePropertyController::class, 'storeProperty'])->name('property.create');




// Rent
    Route::get('/Property/rent', [RentPropertyController::class, 'index']);

// View Request
    Route::get('/view-request', [ManagePropertyController::class, 'viewRequest']);

// Property Image Delete
    Route::get('/delete-image/{id}', [ManagePropertyController::class, 'deletePropertyImage']);

//! Property Routes End

// Developer
    Route::get('/developers', [DeveloperController::class, 'manageDeveloper']);
    Route::get('/developer/add', [DeveloperController::class, 'addDeveloper'])->middleware('super.admin');
    Route::get('/developer/{id}', [DeveloperController::class, 'developerDetail']);
    Route::get('developer-delete/{id}', [DeveloperController::class, 'deleteDeveloper']);


//  Category Route
    Route::resource('categories', CategoryController::class);

//  Purpose Route
    Route::resource('purposes', PurposeController::class);

// Settings Route
    Route::get('/settings', [SettingsController::class, 'index']);

// Payment Method
    Route::get('/settings/payment-method', [PaymentMethodController::class, 'index']);


// Pages
    Route::resource('pages', PageController::class);
    Route::post('/pages/update/{id}', [PageController::class, 'updatePage'])->name('pages.updatePage');
});


Route::get('/run-migrate', function(){
    \Illuminate\Support\Facades\Artisan::call('migrate');
});
