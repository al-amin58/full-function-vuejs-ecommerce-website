<?php $__env->startSection('title', __('Page Expired')); ?>
<?php $__env->startSection('code', '419'); ?>
<?php $__env->startSection('message', __('Page Expired')); ?>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Programme/CTP/iso-backend-new/vendor/laravel/framework/src/Illuminate/Foundation/Exceptions/views/419.blade.php ENDPATH**/ ?>